package com.salesforceselen.excel;

public interface Excel {

}
