package com.salesforceselen.core;

import org.openqa.selenium.WebDriver;

public class SalesforceLex extends DriverInit{

	public SalesforceLex(WebDriver w_driver) {
		super(w_driver);
	}

}
