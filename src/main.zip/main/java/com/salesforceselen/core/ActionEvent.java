package com.salesforceselen.core;

public class ActionEvent {
	
	public void click(){
		
	}
	
}
