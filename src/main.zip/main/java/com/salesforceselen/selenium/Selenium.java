package com.salesforceselen.selenium;

import java.util.List;
import org.openqa.selenium.WebElement;

public interface Selenium {
	
	List<WebElement> return_webelements(String xpathObj);

}
