package com.salesforceselen.datetime;

public interface DatetimeUtils {

}
